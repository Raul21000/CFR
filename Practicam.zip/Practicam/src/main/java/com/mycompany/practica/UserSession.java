/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practica;

/**
 *
 * @author thepy
 */
public class UserSession {
    private static String email;
    private static String name;
    private static int age;
    
    public static void setUser(String userEmail, String userName, int userAge){
        email=userEmail;
        name=userName;
        age=userAge;
    }
    public static String getEmail(){
        return email;
    }

    public static String getName() {
        return name;
    }

    public static int getAge() {
        return age;
    }
    public static void clear(){
        email=null;
        name=null;
        age=0;
    }
}
