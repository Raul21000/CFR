/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.practica;

import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
/**
 *
 * @author thepy
 */
public class CustomerLogin extends javax.swing.JFrame {
    private Connection connection;
    /**
     * Creates new form CustomerLogin
     */
    
    public CustomerLogin(Connection conn) {
        this.connection=conn;
        initComponents();
        setTitle("Customer Interface");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Delete Account");
        jButton1.setPreferredSize(new java.awt.Dimension(120, 30));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("View Tickets");
        jButton2.setPreferredSize(new java.awt.Dimension(120, 30));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("View Routes");
        jButton3.setPreferredSize(new java.awt.Dimension(120, 30));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("Go Back");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(139, 139, 139)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(140, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton4)
                .addGap(27, 27, 27))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(70, Short.MAX_VALUE)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addGap(29, 29, 29))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        int confirm = JOptionPane.showConfirmDialog(this,"Are you sure you want to delete your account?","Confirm Deletion",JOptionPane.YES_NO_OPTION);

         if (confirm == JOptionPane.YES_OPTION) {
         try {
        String sql = "DELETE FROM customer WHERE email = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        String emailUser=UserSession.getEmail();
        System.out.println("Deleting account with email: " + emailUser);
        
        ps.setString(1, emailUser);
        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Account successfully deleted.");
        }
        ps.close();
            this.dispose();
            new LoginInterface(connection).setVisible(true);}
        catch (SQLException e){
        e.printStackTrace();
         JOptionPane.showMessageDialog(this, "Error deleting account: " + e.getMessage());
    }  }  
    }//GEN-LAST:event_jButton1ActionPerformed
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
        new RouteSelection(connection).setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String email = UserSession.getEmail();  // email-ul utilizatorului logat
            if (email == null || email.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "User is not logged in.");
                return;
            }

            try {
                // Găsește id-ul clientului pe baza email-ului
                PreparedStatement psCustomer = connection.prepareStatement("SELECT idcustomer FROM customer WHERE email = ?");
                psCustomer.setString(1, email);
                ResultSet rsCustomer = psCustomer.executeQuery();

                if (!rsCustomer.next()) {
                    JOptionPane.showMessageDialog(null, "No customer found with email: " + email);
                    return;
                }

                int idCustomer = rsCustomer.getInt("idcustomer");

                // Selectează biletele doar ale acelui client
                PreparedStatement psTickets = connection.prepareStatement(
                    "SELECT idticket, idtrain, startLoc, destLoc, totalTime, totalKm, price, class FROM tickets WHERE idcustomer = ?"
                );
                psTickets.setInt(1, idCustomer);
                ResultSet rsTickets = psTickets.executeQuery();

                StringBuilder message = new StringBuilder("Your Tickets:\n");
                boolean found = false;

                while (rsTickets.next()) {
                    found = true;
                    int idTicket = rsTickets.getInt("idticket");
                    String idTrain = rsTickets.getString("idtrain");
                    String startLoc = rsTickets.getString("startLoc");
                    String destLoc = rsTickets.getString("destLoc");
                    String totalTime = rsTickets.getString("totalTime");
                    double totalKm = rsTickets.getDouble("totalKm");
                    double price = rsTickets.getDouble("price");
                    String ticketClass = rsTickets.getString("class");

                    message.append(String.format(
                        "Id: %d, Trenul: %s, Ruta: %s --> %s, Timpul Total: %s, Distanța Totală: %.2f km, Preț: %.2f, Clasa: %s\n",
                        idTicket, idTrain, startLoc, destLoc, totalTime, totalKm, price, ticketClass
                    ));
                }

                if (!found) {
                    message.append("No tickets found for this account.");
                }

                JOptionPane.showMessageDialog(null, message.toString());

                rsCustomer.close();
                rsTickets.close();
                psCustomer.close();
                psTickets.close();

            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
            }  
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        new LoginInterface(connection).setVisible(true);
        UserSession.clear();
        dispose();
    }//GEN-LAST:event_jButton4ActionPerformed
    
    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    // End of variables declaration//GEN-END:variables
}
