package practica;

import java.sql.*;

public class Practica {

    public static void main(String[] args) {
        System.out.println(System.getProperty("file.encoding"));
        String url = "jdbc:mysql://localhost:3306/cfr_database?useSSL=false&useUnicode=true&characterEncoding=utf8";
        String user = "root";
        String password = "fxQ6MEBP2ypj7n7!";

        try {
            System.out.println("Attempting to connect to the database...");
            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the database successfully!");
            new LoginInterface(conn).setVisible(true);

        } catch (SQLException e) {
            System.out.println("Connection failed:");
            e.printStackTrace();
        }
        
    }
}
